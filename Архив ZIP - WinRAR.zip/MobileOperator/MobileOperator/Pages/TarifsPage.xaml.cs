﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MobileOperator.Classes;
using MobileOperator.Pages;
using Newtonsoft.Json;
using System.IO;
using System.Runtime.Serialization;


namespace MobileOperator.Pages
{
    /// <summary>
    /// Логика взаимодействия для TarifsPage.xaml
    /// </summary>
    public partial class TarifsPage : Page
    {
        public static MobOperatorEntities _context = new MobOperatorEntities();

        public TarifsPage()
        {
            InitializeComponent();
            DGridTarifs.ItemsSource = MobOperatorEntities.GetContext().Tarifs.ToList();

            CmbFiltrTarif.ItemsSource = MobOperatorEntities.GetContext().Tarifs.ToList();
            CmbFiltrTarif.SelectedValuePath = "Id_Tarifs";
            CmbFiltrTarif.DisplayMemberPath = "Name";
        }

        private void CmbFiltrTarif_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int id = CmbFiltrTarif.SelectedIndex + 1;
            DGridTarifs.ItemsSource = MobOperatorEntities.GetContext().Tarifs.Where(x => x.Id_Tarifs == id).ToList();
        }

        private void BtnResetAll_Click(object sender, RoutedEventArgs e)
        {
            DGridTarifs.ItemsSource = MobOperatorEntities.GetContext().Tarifs.ToList();

        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            //динамическое отображение данных или изменение данных
            if (Visibility == Visibility.Visible)
            {
                MobOperatorEntities.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                DGridTarifs.ItemsSource = MobOperatorEntities.GetContext().Tarifs.ToList();
            }
        }

        private void RbUp_Checked(object sender, RoutedEventArgs e)
        {
            DGridTarifs.ItemsSource = MobOperatorEntities.GetContext().Tarifs.OrderBy(x => x.Gb).ToList();
        }

        private void RbDown_Checked(object sender, RoutedEventArgs e)
        {
            DGridTarifs.ItemsSource = MobOperatorEntities.GetContext().Tarifs.OrderByDescending(x => x.Gb).ToList();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddEditTarifsPage(null));
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            var tarifForRemoving = DGridTarifs.SelectedItems.Cast<Tarifs>().ToList();

            if (MessageBox.Show($"Вы действительно хотите удалить {tarifForRemoving.Count()} данный тариф?",
                "Внимание!", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    MobOperatorEntities.GetContext().Tarifs.RemoveRange(tarifForRemoving);
                    MobOperatorEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");

                    DGridTarifs.ItemsSource = MobOperatorEntities.GetContext().Tarifs.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            //редактирование
            ClassFrame.frmObj.Navigate(new AddEditTarifsPage((sender as Button).DataContext as Tarifs));
        }

        private void BtnNum_Click(object sender, RoutedEventArgs e)
        {
            int countRow = DGridTarifs.Items.Count;
            TxtNum.Text = countRow.ToString();
        }

        private void BtnSaveJson_Click(object sender, RoutedEventArgs e)
        {
            File.WriteAllText("input.json", string.Empty);//удаление содержимого файла
            foreach (Tarifs nt in MobOperatorEntities.GetContext().Tarifs)//перебирание записей в таблице
                File.AppendAllText("input.json", JsonConvert.SerializeObject(nt));
        }

        private void BtnSearchJson_Click(object sender, RoutedEventArgs e)
        {
            List<Tarifs> tar = new List<Tarifs>();//Список записок
            JsonTextReader reader = new JsonTextReader(new StreamReader("input.json"));//Открытие файла
            reader.SupportMultipleContent = true;
            while (reader.Read())//Пока не закончатся записи
            {
                JsonSerializer serializer = new JsonSerializer();
                Tarifs temp_point = serializer.Deserialize<Tarifs>(reader); // 1 записка
                if (temp_point.Name.Contains(TxtSearchJson.Text)) //Отображение по совпадению с поиском
                    tar.Add(temp_point);
            }
            DGridTarifs.ItemsSource=tar;
            if(TxtSearchJson.Text==string.Empty)
                DGridTarifs.ItemsSource= MobOperatorEntities.GetContext().Tarifs.ToList();
            

        }
    }
}
