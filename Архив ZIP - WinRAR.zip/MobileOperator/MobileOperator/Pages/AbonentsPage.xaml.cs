﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MobileOperator.Classes;
using MobileOperator.Pages;
using Excel = Microsoft.Office.Interop.Excel;


namespace MobileOperator.Pages
{
    /// <summary>
    /// Логика взаимодействия для AbonentsPage.xaml
    /// </summary>
    public partial class AbonentsPage : Page
    {
        

        public AbonentsPage()
        {
            InitializeComponent();
            DGridAbonents.ItemsSource = MobOperatorEntities.GetContext().Tarifs.ToList();

            
        }

        private void TxbSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            DGridAbonents.ItemsSource = MobOperatorEntities.GetContext().Abonents.Where(x => x.LastName.ToLower().Contains(TxbSearch.Text.ToLower())).ToList();
        }

        private void BtnResetAll_Click(object sender, RoutedEventArgs e)
        {
            DGridAbonents.ItemsSource = MobOperatorEntities.GetContext().Tarifs.ToList();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddEditAbonentsPage(null));
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            var abonentForRemoving = DGridAbonents.SelectedItems.Cast<Abonents>().ToList();

            if (MessageBox.Show($"Вы действительно хотите удалить {abonentForRemoving.Count()} данный абонента?",
                "Внимание!", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    MobOperatorEntities.GetContext().Abonents.RemoveRange(abonentForRemoving);
                    MobOperatorEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");

                    DGridAbonents.ItemsSource = MobOperatorEntities.GetContext().Abonents.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            //редактирование
            ClassFrame.frmObj.Navigate(new AddEditAbonentsPage((sender as Button).DataContext as Abonents));
        }

        private void BtnExcel_Click(object sender, RoutedEventArgs e)
        {
            // объект Excel
            var app = new Excel.Application();

            // книга
            Excel.Workbook wb = app.Workbooks.Add();

            // лист
            Excel.Worksheet worksheet = app.Worksheets.Item[1];
            int indexRows = 3;

            Excel.Range TitleRange = worksheet.Range[worksheet.Cells[1][indexRows - 2], worksheet.Cells[7][indexRows - 2]];
            TitleRange.Merge();
            TitleRange.Value = "Ведомость о всех абонентах и нформация о них";
            TitleRange.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
            TitleRange.Font.Italic = true;
            TitleRange.Font.Name = "Times New Roman";


            // ячейки
            // 1 - номер столбца 
            // 2 - номер строки
            worksheet.Cells[1][indexRows] = "№";
            worksheet.Cells[2][indexRows] = "Фамилия";
            worksheet.Cells[3][indexRows] = "Имя";
            worksheet.Cells[4][indexRows] = "Отчество";
            worksheet.Cells[5][indexRows] = "Серия паспорта";
            worksheet.Cells[6][indexRows] = "Номер паспорта";
            worksheet.Cells[7][indexRows] = "Телефон";
            var printItems = DGridAbonents.Items;

            Excel.Range Bold = worksheet.Range[worksheet.Cells[1][indexRows], worksheet.Cells[8][indexRows]];
            Bold.Font.Bold = worksheet.Cells[1][indexRows].Font.Bold = true;
            Excel.Range Borders = worksheet.Range[worksheet.Cells[1][3], worksheet.Cells[7][14]];
            Borders.Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle =
            Borders.Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle =
            Borders.Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle =
            Borders.Borders[Excel.XlBordersIndex.xlEdgeTop].LineStyle =
            Borders.Borders[Excel.XlBordersIndex.xlInsideHorizontal].LineStyle = 
            Borders.Borders[Excel.XlBordersIndex.xlInsideVertical].LineStyle = Excel.XlLineStyle.xlContinuous;
            //Borders.ColumnWidth = 30;

            worksheet.Columns.AutoFit();

            worksheet.Columns[2].ColumnWidth = 12;
            worksheet.Columns[3].ColumnWidth = 12;
            worksheet.Columns[4].ColumnWidth = 14;
            worksheet.Columns[7].ColumnWidth = 12;


            
            

            //цикл по данным из таблицы
            foreach (Abonents item in printItems)
            {
                worksheet.Cells[1][indexRows + 1] = indexRows - 2;
                worksheet.Cells[2][indexRows + 1] = item.LastName;
                worksheet.Cells[3][indexRows + 1] = item.FirstName;
                worksheet.Cells[4][indexRows + 1] = item.Patronymic;
                worksheet.Cells[5][indexRows + 1] = item.Series;
                worksheet.Cells[6][indexRows + 1] = item.Number;
                worksheet.Cells[7][indexRows + 1] = item.Phone.ToString();
                indexRows++;
            }
            Excel.Range SignatureRange = worksheet.Range[worksheet.Cells[1][indexRows + 3], worksheet.Cells[3][indexRows + 3]];
            SignatureRange.Merge();
            SignatureRange.Value = "Подпись:";
            SignatureRange.Font.Name = "Times New Roman";
            SignatureRange.Font.Italic = true;

            Excel.Range SealRange = worksheet.Range[worksheet.Cells[5][indexRows + 3], worksheet.Cells[7][indexRows + 3]];
            SealRange.Merge();
            SealRange.Value = "Печать:";
            SealRange.Font.Name= "Times New Roman";
            SealRange.Font.Italic = true;

            worksheet.Range[worksheet.Cells[1][3], worksheet.Cells[7][14]].Font.Name = "Times New Roman";

            // показать Excel
            app.Visible = true;
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            //динамическое отображение данных или изменение данных
            if (Visibility == Visibility.Visible)
            {
                MobOperatorEntities.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                DGridAbonents.ItemsSource = MobOperatorEntities.GetContext().Abonents.ToList();
            }
        }

        private void RbUp_Checked(object sender, RoutedEventArgs e)
        {
            DGridAbonents.ItemsSource = MobOperatorEntities.GetContext().Abonents.OrderBy(x => x.LastName).ToList();
        }

        private void RbDown_Checked(object sender, RoutedEventArgs e)
        {
            DGridAbonents.ItemsSource = MobOperatorEntities.GetContext().Abonents.OrderByDescending(x => x.LastName).ToList();
        }

        private void BtnNum_Click(object sender, RoutedEventArgs e)
        {
            int countRow = DGridAbonents.Items.Count;
            TxtNum.Text = countRow.ToString();
        }
    }
}
