﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MobileOperator.Classes;

namespace MobileOperator.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditTarifsPage.xaml
    /// </summary>
    public partial class AddEditTarifsPage : Page
    {
        private Tarifs _currentTarifs = new Tarifs();

        public AddEditTarifsPage(Tarifs selectedTarifs) // в конструктор добавлен параметр типа Tarifs
        {
            InitializeComponent();
            //создаём контекст  
            
            if (selectedTarifs != null)
                _currentTarifs = selectedTarifs;
            //создаем контекст
            DataContext = _currentTarifs;
            
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder(); //объект для сообщения об ошибке

            //проверка полей объекта
            if (string.IsNullOrWhiteSpace(_currentTarifs.Name))
                error.AppendLine("Укажите название");
            //if (string.IsNullOrWhiteSpace(_currentProduct.Note))
            //    error.AppendLine("Укажите описание товара");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            //если пользователь новый
            if (_currentTarifs.Id_Tarifs == 0)
                MobOperatorEntities.GetContext().Tarifs.Add(_currentTarifs); //добавить в контекст
            try
            {
                MobOperatorEntities.GetContext().SaveChanges(); // сохраняет все изменения
                MessageBox.Show("Новый продукт добавлен");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString()); //сообщение об ошибке
            }
        }

        
    }
}
